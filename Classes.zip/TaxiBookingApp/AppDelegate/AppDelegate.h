//
//  AppDelegate.h
//  TaxiBookingApp
//
//  Created by disha  on 7/5/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

