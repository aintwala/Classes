//
//  UIView+Utility.h
//  ZeroTrace
//
//  Created by datt on 5/30/17.
//  Copyright © 2017 zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView(Utility)
@property (nonatomic) IBInspectable UIColor *borderColor;
@property (nonatomic) IBInspectable CGFloat borderWidth;
@property (nonatomic) IBInspectable CGFloat cornerRadius;
@end
