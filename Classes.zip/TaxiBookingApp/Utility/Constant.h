
#ifndef ChallengeMe_Constant_h
#define ChallengeMe_Constant_h

#define appDelegate ((AppDelegate*)[[UIApplication sharedApplication] delegate])

#define kFontName @"OpenSans-SemiBold"

#define BASE_URL        @"http://xyz"
#define GEOCODE_API_KEY @"AIzaSyB7l0RKXG2hDfpYLae-HnjQs1i3u1fdNl8"

#define API_LOG_IN           (BASE_URL@"ws_login")

#define storyboardMain  (UIStoryboard *)[UIStoryboard storyboardWithName:@"Main" bundle: nil]

#define pushViewController(key)  [[SlideNavigationController sharedInstance] pushViewController:[storyboardMain instantiateViewControllerWithIdentifier:(key)] animated:YES]

#endif
#define CommentCellFont  [UIFont fontWithName:@"AvenirNextCondensed-Regular" size:14]

#define IS_IPHONE4 (([[UIScreen mainScreen] bounds].size.height-480)?NO:YES)
#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)

#define IS_IPHONE6 (([[UIScreen mainScreen] bounds].size.height-667)?NO:YES)
#define IS_IPHONE6plus (([[UIScreen mainScreen] bounds].size.height-736)?NO:YES)



#define IS_OS_5_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.0)
#define IS_OS_6_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 6.0)
#define IS_OS_7_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
#define IS_OS_8_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define DEVICE_FRAME [[ UIScreen mainScreen ] bounds ]

#define RGB(r,g,b)    [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define BG_COLOR        RGB(33,60,136)
#define LightGray_COLOR [UIColor colorWithRed:(246.0/255.0) green:(246.0/255.0) blue:(249.0/255.0) alpha:1];
#define LightBlue_COLOR [UIColor colorWithRed:(45.0/255.0) green:(186.0/255.0) blue:(241.0/255.0) alpha:1];
#define DarkBlue_COLOR [UIColor colorWithRed:(28.0/255.0) green:(48.0/255.0) blue:(84.0/255.0) alpha:1];

#define RECT(x,y,w,h)  CGRectMake(x, y, w, h)
#define POINT(x,y)     CGPointMake(x, y)
#define SIZE(w,h)      CGSizeMake(w, h)
#define RANGE(loc,len) NSMakeRange(loc, len)


#define UDSetObject(value, key) [[NSUserDefaults standardUserDefaults] setObject:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetValue(value, key) [[NSUserDefaults standardUserDefaults] setValue:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetInt(value, key) [[NSUserDefaults standardUserDefaults] setInteger:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetFloat(value, key) [[NSUserDefaults standardUserDefaults] setFloat:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetBool(value, key) [[NSUserDefaults standardUserDefaults] setBool:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]

#define UDGetObject(key) [[NSUserDefaults standardUserDefaults] objectForKey:(key)]
#define UDGetValue(key) [[NSUserDefaults standardUserDefaults] valueForKey:(key)]
#define UDGetInt(key) [[NSUserDefaults standardUserDefaults] integerForKey:(key)]
#define UDGetFloat(key) [[NSUserDefaults standardUserDefaults] floatForKey:(key)]
#define UDGetBool(key) [[NSUserDefaults standardUserDefaults] boolForKey:(key)]

#define UDRemoveObject(key) [[NSUserDefaults standardUserDefaults] removeObjectForKey:(key)]


#define dt_time_formatter @"yyyy-MM-dd HH:mm:ss"
#define dt_formatter @"yyyy-mm-dd"
#define time_formatter @"HH:mm:ss"
#define APPDATA [ApplicationData sharedInstance]


#ifdef DEBUG
#define DLog(s, ...) NSLog(s, ##__VA_ARGS__)
#else
#define DLog(s, ...)
#endif

typedef enum {
    HTTPRequestTypeGeneral,
    HTTPRequestTypeUpdate,
    HTTPRequestTypeImageList,
    HTTPRequestTypeVideoList,
    HTTPRequestTypePlaceList,
    HTTPRequestTypePlaceDetail,
    HTTPRequestTypeLogin,
    HTTPRequestTypeDoctorLogin,
    HTTPRequestTypeChangePassword,
    HTTPRequestTypeActiveConcernDetail,
    HTTPRequestTypeDoctorConcernList,
    HTTPRequestTypeStaffList,
    HTTPRequestTypeDoctorInfo,
} HTTPRequestType;

typedef enum {
    jServerError = 0,
    jSuccess,
    jInvalidResponse,
    jNetworkError,
    jFailResponse,
}ErrorCode;
//Social Media ID
