//
//  UIView+Utility.m
//  ZeroTrace
//
//  Created by datt on 5/30/17.
//  Copyright © 2017 zaptechsolutions. All rights reserved.
//

#import "UIView+Utility.h"

@implementation UIView(Utility)
@dynamic borderColor,borderWidth,cornerRadius;

-(void)setBorderColor:(UIColor *)borderColor{
    [self.layer setBorderColor:borderColor.CGColor];
}

-(void)setBorderWidth:(CGFloat)borderWidth{
    [self.layer setBorderWidth:borderWidth];
}

-(void)setCornerRadius:(CGFloat)cornerRadius{
    [self.layer setCornerRadius:cornerRadius];
}
@end
