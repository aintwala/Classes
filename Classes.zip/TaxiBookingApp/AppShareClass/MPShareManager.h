//
//  MPShareManager.h
//  MusicPlayer
//
//  Created by datt on 6/7/17.
//  Copyright © 2017 zaptechsolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"

@interface MPShareManager : NSObject
{
    MBProgressHUD *hud;
}
@property (nonatomic) BOOL isRegister;
@property (nonatomic) BOOL isUpdate;
@property (nonatomic) NSString *strOtpMobileNo;
@property (nonatomic) NSString *strFirstName;
@property (nonatomic) NSString *strLastName;
@property (nonatomic) NSString *strMobileNumber;
@property (nonatomic) NSString *strUserId;
@property (nonatomic) NSString *strSetPickupDate;
@property (nonatomic) double latHome,longHome,latWork,longWork;


+ (id)sharedManager;
@end
