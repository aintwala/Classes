//
//  MPShareManager.m
//  MusicPlayer
//
//  Created by datt on 6/7/17.
//  Copyright © 2017 zaptechsolutions. All rights reserved.
//

#import "MPShareManager.h"

@implementation MPShareManager
+ (id)sharedManager {
    static MPShareManager *mpShareManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mpShareManager = [self new];
    });
    return mpShareManager;
}
- (id) init {
    self = [super init];
    if (self) {
        _isRegister = NO;
        _isUpdate = NO;
    }
    return self;
}
@end
