//
//  MapViewVC.h
//  MyTaxiApp
//
//  Created by disha on 7/4/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>
#import <GooglePlaces/GooglePlaces.h>
#import "SlideNavigationController.h"
#import "SelectDateVC.h"
static CGFloat kOverlayHeight = 220.0f;
@interface MapViewVC : UIViewController <GMSMapViewDelegate,CLLocationManagerDelegate,SlideNavigationControllerDelegate,UITextFieldDelegate,GMSAutocompleteViewControllerDelegate, UIPickerViewDelegate,setDateTimeDelegate>
{
    GMSMapView *_mapView;
    BOOL _firstLocationUpdate,isFavourite,isToPlace;
    double toPlaceLat,toPlaceLong,fromPlaceLat,fromPlaceLong;
    NSMutableArray *waypoints,*waypointStrings;
    GMSMarker *markerTo,*markerFrom, *markerCurrentLocation;
    GMSCameraPosition *camera,*cameraPoint,*lastCameraPosition;
    CLLocation *currentLocation;
    CLLocationManager *locationManager;
    NSString *strHomePlace,*strWorkPlace;
    NSIndexPath *index;
    UIDatePicker *datepicker;
    UIView *viewForDatePicker;
    CGPoint centerPointViewPlace;
    int btnTag;
    MPShareManager *objShareManager;
    CLLocationCoordinate2D coordPinDrag;
}

@property (weak, nonatomic) IBOutlet UIView *viewCarSelection;
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property (weak, nonatomic) IBOutlet UITextField *txtToPlace;
@property (weak, nonatomic) IBOutlet UIView *viewLocation;
@property (weak, nonatomic) IBOutlet UITextField *txtFromPlace;
@property (weak, nonatomic) IBOutlet UIView *viewMapView;
@property (weak, nonatomic) IBOutlet UITableView *tblFavouritePlace;
@property (weak, nonatomic) IBOutlet UIView *viewFavouritePlace;
@property (weak, nonatomic) IBOutlet UIButton *btnRequestRide;
@property (weak, nonatomic) IBOutlet UIButton *btnWhereTo;
@property (weak, nonatomic) IBOutlet UIButton *btnScheduleRide;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectedDateTime;
@property (weak, nonatomic) IBOutlet UIButton *btnCarViewDateTime;
@property (weak, nonatomic) IBOutlet UIImageView *imgPin;
@property (weak, nonatomic) IBOutlet UIButton *btnDrawRoute;
//
- (IBAction)btnCarSelectionAction:(id)sender;
- (IBAction)btnScheduleRideAction:(UIButton *)sender;
- (IBAction)btnRequestCarAction:(id)sender;
- (IBAction)btnBackAction:(id)sender;
- (IBAction)btnWhereToAction:(id)sender;
- (IBAction)btnDrawRouteAction:(id)sender;

@end
