//
//  SelectDateVC.h
//  TaxiBookingApp
//
//  Created by dharmesh  on 7/13/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol setDateTimeDelegate <NSObject>
-(void)setDateAndTime:(NSString *)strDateTime;
@end

@interface SelectDateVC : UIViewController
{
    MPShareManager *objShareManager;
}

@property (weak, nonatomic) IBOutlet UIView *viewSelectDatePicker;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) id <setDateTimeDelegate> delegate;
//
- (IBAction)btnSetPickUpTimeAction:(id)sender;

@end
