//
//  SelectDateVC.m
//  TaxiBookingApp
//
//  Created by dharmesh  on 7/13/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "SelectDateVC.h"

@interface SelectDateVC ()
@end
@implementation SelectDateVC

- (void)viewDidLoad {
    [super viewDidLoad];
    objShareManager = [MPShareManager sharedManager];
    [_datePicker addTarget:self action:@selector(dateIsChanged:) forControlEvents:UIControlEventValueChanged];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Button Action -

- (IBAction)btnSetPickUpTimeAction:(id)sender {
    if (objShareManager.strSetPickupDate!= nil) {
    [_delegate setDateAndTime:objShareManager.strSetPickupDate];
    }
    else {
    [self SetDateFormat:[_datePicker date]];
    [_delegate setDateAndTime:objShareManager.strSetPickupDate];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark -  DatePickerValuechanged Method -

- (void)dateIsChanged:(id)sender {
    [_datePicker setMinimumDate:[NSDate date]];
    [self SetDateFormat:[_datePicker date]];
}

-(void)SetDateFormat:(NSDate *)date {
    _lblDate.text = [NSString stringWithFormat:@"%@",_datePicker.date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"E,MMM dd 'at' hh:mm a"];
    NSString *strFromDate = [dateFormatter stringFromDate:date];
    NSTimeInterval secondsInEightHours = 15 * 60 ;
    NSDate *dateEightHoursAhead = [date dateByAddingTimeInterval:secondsInEightHours];
    [dateFormatter setDateFormat:@"hh:mm a"];
    NSString *strFromDate1 = [dateFormatter stringFromDate:dateEightHoursAhead];
    objShareManager.strSetPickupDate = [NSString stringWithFormat:@"%@ - %@",strFromDate,strFromDate1];
    _lblDate.text = [NSString stringWithFormat:@"%@ - %@",strFromDate,strFromDate1];
}

@end
