//
//  MapViewVC.m
//  MyTaxiApp
//
//  Created by disha on 7/4/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "MapViewVC.h"

@interface MapViewVC ()

@end

@implementation MapViewVC

- (void)viewDidLoad {
    [super viewDidLoad];
    objShareManager = [MPShareManager sharedManager];
    [self.navigationController.navigationBar setHidden:NO];
    self.title = @"Book Taxi";
    centerPointViewPlace = _viewFavouritePlace.center;
    viewForDatePicker = [UIView new];
    datepicker = [UIDatePicker new];
    SelectDateVC *objSelectDateVC = [storyboardMain instantiateViewControllerWithIdentifier:@"SelectDateVC"];
    objSelectDateVC.delegate = self;
    [self pinCurrentLocation];
    //
    UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [panRecognizer setMinimumNumberOfTouches:1];
    [panRecognizer setMaximumNumberOfTouches:1];
    [self.viewFavouritePlace addGestureRecognizer:panRecognizer];
}

-(void)viewWillAppear:(BOOL)animated
{
    if (!isFavourite) {
        [self setViewFrame];
    }
}

- (void)dealloc {
    [_mapView removeObserver:self
                  forKeyPath:@"myLocation"
                     context:NULL];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SetDateTime Delegate -

-(void)setDateAndTime:(NSString *)strDateTime{
    if (btnTag == 1){
        [_btnSelectedDateTime setTitle:strDateTime forState:UIControlStateNormal];
        [UIView animateWithDuration:0.5 animations:^{
            _viewLocation.frame = CGRectMake(0, 0, _viewLocation.frame.size.width, _viewLocation.frame.size.height);[self.navigationController.navigationBar setHidden:YES];
            _viewFavouritePlace.frame = CGRectMake(0, self.view.frame.size.height - _viewFavouritePlace.frame.size.height, _viewFavouritePlace.frame.size.width, _viewFavouritePlace.frame.size.height);
        } completion:^(BOOL finished) {
            _btnWhereTo.hidden=YES;
            //[movingMarker setIcon:[UIImage imageNamed:@"movingPin"]];
            //movingMarker.map = _mapView;
            _imgPin.hidden = NO;
            _mapView.delegate = self;
        }];
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"Request Ride \n %@",strDateTime]];
        [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(12, str.length-12)];
        _btnRequestRide.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        _btnRequestRide.titleLabel.numberOfLines = 2;
        _btnRequestRide.titleLabel.textAlignment = NSTextAlignmentCenter; // if u need
        [_btnRequestRide setAttributedTitle:str forState:UIControlStateNormal];
        _btnCarViewDateTime.hidden = YES;
        _btnRequestRide.frame = CGRectMake(20, _viewCarSelection.frame.size.height-60, _viewCarSelection.frame.size.width-40, _btnRequestRide.frame.size.height);
    }
    else if (btnTag == 2){
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"Request Ride \n %@",strDateTime]];
        [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(12, str.length-12)];
        _btnRequestRide.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        _btnRequestRide.titleLabel.numberOfLines = 2;
        _btnRequestRide.titleLabel.textAlignment = NSTextAlignmentCenter; // if u need
        [_btnRequestRide setAttributedTitle:str forState:UIControlStateNormal];
    }
    else if (btnTag == 3){
        [_btnSelectedDateTime setTitle:strDateTime forState:UIControlStateNormal];
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"Request Ride \n %@",strDateTime]];
        [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(12, str.length-12)];
        _btnRequestRide.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        _btnRequestRide.titleLabel.numberOfLines = 2;
        _btnRequestRide.titleLabel.textAlignment = NSTextAlignmentCenter; // if u need
        [_btnRequestRide setAttributedTitle:str forState:UIControlStateNormal];
    }
}

#pragma mark - UIPanGestureRecognizer Method -

-(void)setViewFrame{
    _viewCarSelection.frame = CGRectMake(0, self.view.frame.size.height + _viewCarSelection.frame.size.height, _viewCarSelection.frame.size.width, _viewCarSelection.frame.size.height);
    _viewLocation.frame = CGRectMake(0,self.view.frame.origin.y - _viewLocation.frame.size.height, _viewLocation.frame.size.width, _viewLocation.frame.size.height);
    _viewFavouritePlace.frame = CGRectMake(0, self.view.frame.size.height + _viewFavouritePlace.frame.size.height, _viewFavouritePlace.frame.size.width, _viewFavouritePlace.frame.size.height);
    viewForDatePicker.frame = CGRectMake(0, self.view.frame.size.height + viewForDatePicker.frame.size.height, self.view.frame.size.width, 300);
}

#pragma mark - UIPanGestureRecognizer Method -

- (void)handlePan:(UIPanGestureRecognizer *)recognizer
{
    CGPoint translation = [recognizer translationInView:self.view];
    recognizer.view.center = CGPointMake(recognizer.view.center.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self.view];
    if (_viewFavouritePlace.center.y <
        centerPointViewPlace.y)
    {
        _viewFavouritePlace.center =  centerPointViewPlace;
    }
    if (recognizer.state == UIGestureRecognizerStateEnded || recognizer.state == UIGestureRecognizerStateBegan) {
        
        CGPoint velocity = [recognizer velocityInView:self.view];
        CGFloat magnitude = sqrtf((velocity.x * velocity.x) + (velocity.y * velocity.y));
        CGFloat slideMult = magnitude / 200;
        NSLog(@"magnitude: %f, slideMult: %f", magnitude, slideMult);
        
        float slideFactor = 3.0 * slideMult; // Increase for more of a slide
        CGPoint finalPoint = CGPointMake(0,
                                         recognizer.view.center.y + (velocity.y * slideFactor));
        
        finalPoint.x =  recognizer.view.center.x;
        finalPoint.y =  self.view.frame.size.height + 100;
        
        if (recognizer.view.frame.origin.y <= centerPointViewPlace.y) {
            
            [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                recognizer.view.center = centerPointViewPlace;
            } completion:nil];
        }
        else if(recognizer.view.frame.origin.y >= centerPointViewPlace.y)
        {
            [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                recognizer.view.center = finalPoint;
            } completion:nil];
        }
    }
}

#pragma mark - UITextField Delegate Method -

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField ==_txtToPlace)
    {
        isFavourite = NO;
        isToPlace = YES;
        GMSAutocompleteViewController *acController = [[GMSAutocompleteViewController alloc] init];
        acController.delegate = self;
        [self presentViewController:acController animated:YES completion:nil];
        return NO;
    }
    if (textField ==_txtFromPlace)
    {
        isToPlace = NO;
        isFavourite = NO;
        GMSAutocompleteViewController *acController = [[GMSAutocompleteViewController alloc] init];
        acController.delegate = self;
        [self presentViewController:acController animated:YES completion:nil];
        return NO;
    }
    return YES;
}

#pragma mark - slideNavigationController Delegate Method -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

#pragma mark - TableView Delegates -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    AddFavouritePlaceTblCell *cell = [_tblFavouritePlace dequeueReusableCellWithIdentifier:CellIdentifier];
    if (indexPath.row == 0) {
        cell.lblAddPlace.text = @"Add Home";
        cell.lblPlace.text = strHomePlace;
    } else {
        cell.lblAddPlace.text = @"Add Work";
        cell.lblPlace.text = strWorkPlace;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AddFavouritePlaceTblCell *cell = [_tblFavouritePlace cellForRowAtIndexPath:indexPath];
    index = indexPath;
    if ((cell.lblPlace.text.length == 0)) {
        isFavourite = YES;
        GMSAutocompleteViewController *acController = [[GMSAutocompleteViewController alloc] init];
        acController.delegate = self;
        [self presentViewController:acController animated:YES completion:nil];
    } else {
        isFavourite = YES;
        [UIView animateWithDuration:0.50 animations:^{
            _viewLocation.frame = CGRectMake(0,self.view.frame.origin.y - _viewLocation.frame.size.height, _viewLocation.frame.size.width, _viewLocation.frame.size.height);
            _viewFavouritePlace.frame = CGRectMake(0, self.view.frame.size.height + _viewFavouritePlace.frame.size.height, _viewFavouritePlace.frame.size.width, _viewFavouritePlace.frame.size.height);
        }];
        _mapView.delegate = nil;
        _imgPin.hidden = true;
        [self routeBetweenTwoLocation];
    }
}

#pragma mark - Button Action -

- (IBAction)btnBackAction:(UIButton*)sender {
    if (sender.tag == 10)
    {
        [UIView animateWithDuration:0.50 animations:^{
            _viewCarSelection.frame = CGRectMake(0, self.view.frame.size.height + _viewCarSelection.frame.size.height, _viewCarSelection.frame.size.width, _viewCarSelection.frame.size.height);
        }];
        [_mapView clear];
        _btnBack.hidden=YES;
        [self.navigationController.navigationBar setHidden:NO];
        _btnWhereTo.hidden = NO;
        _btnScheduleRide.hidden = NO;
        _txtToPlace.text = @"";
        [_btnSelectedDateTime setTitle:@"" forState:UIControlStateNormal];
        [_btnRequestRide setTitle:@"Request Ride" forState:UIControlStateNormal];
        _imgPin.hidden = YES;
        isFavourite = NO;
        _btnCarViewDateTime.hidden = NO;
        _btnRequestRide.frame = CGRectMake(10, _viewCarSelection.frame.size.height-63, _btnRequestRide.frame.size.width, _btnRequestRide.frame.size.height);
        _mapView.camera = [GMSCameraPosition cameraWithTarget:currentLocation.coordinate zoom:14];
    }
    else if(sender.tag == 20)
    {
        [UIView animateWithDuration:0.50 animations:^{
            _viewLocation.frame = CGRectMake(0,self.view.frame.origin.y - _viewLocation.frame.size.height, _viewLocation.frame.size.width, _viewLocation.frame.size.height);
            _viewFavouritePlace.frame = CGRectMake(0, self.view.frame.size.height + _viewFavouritePlace.frame.size.height, _viewFavouritePlace.frame.size.width, _viewFavouritePlace.frame.size.height);
            [self.navigationController.navigationBar setHidden:NO];
            _btnWhereTo.hidden=NO;
            _btnScheduleRide.hidden = NO;
            [_btnSelectedDateTime setTitle:@"" forState:UIControlStateNormal];
            _imgPin.hidden = YES;
            _mapView.delegate = nil;
            _txtFromPlace.text = @"";
            _btnDrawRoute.hidden = YES;
        }];
        _mapView.camera = [GMSCameraPosition cameraWithTarget:currentLocation.coordinate zoom:14];
    }
}

- (IBAction)btnWhereToAction:(id)sender {
    [UIView animateWithDuration:0.5 animations:^{
        _viewLocation.frame = CGRectMake(0, 0, _viewLocation.frame.size.width, _viewLocation.frame.size.height);[self.navigationController.navigationBar setHidden:YES];
        _viewFavouritePlace.frame = CGRectMake(0, self.view.frame.size.height - _viewFavouritePlace.frame.size.height, _viewFavouritePlace.frame.size.width, _viewFavouritePlace.frame.size.height);
    } completion:^(BOOL finished) {
        _btnWhereTo.hidden=YES;
        _btnScheduleRide.hidden = YES;
        _imgPin.hidden = NO;
        _mapView.delegate = self;
        _btnSelectedDateTime.userInteractionEnabled = NO;
        [_viewMapView addSubview:_imgPin];
    }];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        CLPlacemark * plcMark = ((CLPlacemark *)[placemarks objectAtIndex:0]);
        if (plcMark != nil) {
            [_txtFromPlace setText:plcMark.subAdministrativeArea];
        }
    }];
}

- (IBAction)btnDrawRouteAction:(id)sender {
    [UIView animateWithDuration:0.50 animations:^{
        _viewLocation.frame = CGRectMake(0,self.view.frame.origin.y - _viewLocation.frame.size.height, _viewLocation.frame.size.width, _viewLocation.frame.size.height);
        _viewFavouritePlace.frame = CGRectMake(0, self.view.frame.size.height + _viewFavouritePlace.frame.size.height, _viewFavouritePlace.frame.size.width, _viewFavouritePlace.frame.size.height);
    }];
    [self routeBetweenTwoLocation];
}

- (IBAction)btnCarSelectionAction:(id)sender {
    
}

- (IBAction)btnScheduleRideAction:(UIButton *)sender {
    _btnSelectedDateTime.userInteractionEnabled = YES;
    if (sender.tag == 50)
    {
        btnTag = 1;
    }
    else if(sender.tag == 60){
        btnTag = 2;
    }
    else if(sender.tag == 70){
        btnTag = 3;
    }
    SelectDateVC *objSelectDateVC = [storyboardMain instantiateViewControllerWithIdentifier:@"SelectDateVC"];
    [objSelectDateVC setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    [self.navigationController presentViewController:objSelectDateVC animated:YES completion:^{
        objSelectDateVC.delegate = self;
    }];
}

- (IBAction)btnRequestCarAction:(id)sender {
    
}

#pragma mark - GetDateTime Method -

-(void) ShowSelectedDate {
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [datepicker setMinimumDate:[NSDate date]];
    NSDate *eventDate = datepicker.date;
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    NSLog(@"%@", eventDate);
    [UIView animateWithDuration:0.50 animations:^{
        viewForDatePicker.frame = CGRectMake(0, self.view.frame.size.height + viewForDatePicker.frame.size.height, self.view.frame.size.width, 300);
    }];
}

#pragma mark - Google Current Location Method -

-(void)pinCurrentLocation{
    camera = [GMSCameraPosition cameraWithLatitude:-33.868 longitude:151.2086 zoom:10];
    _mapView = [GMSMapView mapWithFrame:self.view.frame camera:camera];
    _mapView.settings.compassButton = YES;
    _mapView.settings.myLocationButton = YES;
    [_mapView addObserver:self
               forKeyPath:@"myLocation"
                  options:NSKeyValueObservingOptionNew
                  context:NULL];
    [self.viewMapView addSubview:_mapView];
    dispatch_async(dispatch_get_main_queue(), ^{
        _mapView.myLocationEnabled = YES;
    });
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    if (!_firstLocationUpdate) {
        _firstLocationUpdate = YES;
        currentLocation = [change objectForKey:NSKeyValueChangeNewKey];
        _mapView.camera = [GMSCameraPosition cameraWithTarget:currentLocation.coordinate zoom:14];
        fromPlaceLat = currentLocation.coordinate.latitude;
        fromPlaceLong = currentLocation.coordinate.longitude;

        //movingMarker = [GMSMarker markerWithPosition:currentLocation.coordinate];
    }
}

#pragma mark - DrawRoute Method -

- (void)routeBetweenTwoLocation {
    [_mapView clear];
    CLLocation *myOrigin,*myDestination;
    if(isFavourite){
        if(index.row == 0) {
     myOrigin = [[CLLocation alloc] initWithLatitude:fromPlaceLat longitude: fromPlaceLong];
     myDestination = [[CLLocation alloc] initWithLatitude:objShareManager.latHome longitude:objShareManager.longHome];
        }
        else{
            myOrigin = [[CLLocation alloc] initWithLatitude:fromPlaceLat longitude: fromPlaceLong];
            myDestination = [[CLLocation alloc] initWithLatitude:objShareManager.latWork longitude:objShareManager.longWork];
        }
    }
    else{
        myOrigin = [[CLLocation alloc] initWithLatitude:fromPlaceLat longitude: fromPlaceLong];
        myDestination = [[CLLocation alloc] initWithLatitude:toPlaceLat longitude:toPlaceLong];
    }
    markerFrom = [GMSMarker markerWithPosition:myOrigin.coordinate];
    markerFrom.icon = [UIImage imageNamed:@"markerStart"];
    markerFrom.map = _mapView;
    markerTo = [GMSMarker markerWithPosition:myDestination.coordinate];
    markerTo.icon = [UIImage imageNamed:@"markerEnd"];
    markerTo.map = _mapView;
    GMSCoordinateBounds *bounds =
    [[GMSCoordinateBounds alloc] initWithCoordinate:myOrigin.coordinate coordinate:myDestination.coordinate];
    cameraPoint = [_mapView cameraForBounds:bounds insets:UIEdgeInsetsZero];
    _mapView.camera = cameraPoint;
    GMSCameraUpdate *zoomCamera = [GMSCameraUpdate zoomOut];
    [_mapView animateWithCameraUpdate:zoomCamera];
    [self fetchPolylineWithOrigin:myOrigin destination:myDestination completionHandler:^(GMSPolyline *polyline) {
        if(polyline)
            polyline.map = _mapView;
        _btnWhereTo.hidden = YES;
        _btnScheduleRide.hidden = YES;
        _btnBack.hidden=NO;
        _imgPin.hidden = YES;
        _btnDrawRoute.hidden = YES;
        _mapView.delegate = nil;
        [UIView animateWithDuration:0.5 animations:^{
            _viewCarSelection.frame = CGRectMake(0, self.view.frame.size.height - _viewCarSelection.frame.size.height, _viewCarSelection.frame.size.width, _viewCarSelection.frame.size.height);
        }];
    }];
}

- (void)fetchPolylineWithOrigin:(CLLocation *)origin destination:(CLLocation *)destination completionHandler:(void (^)(GMSPolyline *))completionHandler {
    NSString *originString = [NSString stringWithFormat:@"%f,%f", origin.coordinate.latitude, origin.coordinate.longitude];
    NSString *destinationString = [NSString stringWithFormat:@"%f,%f", destination.coordinate.latitude, destination.coordinate.longitude];
    NSString *directionsAPI = @"https://maps.googleapis.com/maps/api/directions/json?";
    NSString *directionsUrlString = [NSString stringWithFormat:@"%@&origin=%@&destination=%@&mode=driving", directionsAPI, originString, destinationString];
    NSURL *directionsUrl = [NSURL URLWithString:directionsUrlString];
    NSURLSessionDataTask *fetchDirectionsTask = [[NSURLSession sharedSession] dataTaskWithURL:directionsUrl completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
        if(error) {
            if(completionHandler) completionHandler(nil);
            return;
        }
        NSArray *routesArray = [json objectForKey:@"routes"];
        __block GMSPolyline *polyline = nil;
        if ([routesArray count] > 0) {
            NSDictionary *routeDict = [routesArray objectAtIndex:0];
            NSDictionary *routeOverviewPolyline = [routeDict objectForKey:@"overview_polyline"];
            NSString *points = [routeOverviewPolyline objectForKey:@"points"];
            __block GMSPath *path = [GMSPath pathFromEncodedPath:points];
            dispatch_sync(dispatch_get_main_queue(), ^{
                polyline = [GMSPolyline polylineWithPath:path];
                if(completionHandler)completionHandler(polyline);
            });
        }
    }];
    [fetchDirectionsTask resume];
}

#pragma mark - GetAddressOnPinMove Method -

- (void)mapView:(GMSMapView *)mapView didChangeCameraPosition:(GMSCameraPosition *)position {
    /* move draggable pin */
    if (_imgPin) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            // stick it on map and start dragging from there..
            if (lastCameraPosition == nil) lastCameraPosition = position;
            CGPoint touchPoint = CGPointMake(_imgPin.frame.origin.x+_imgPin.frame.size.width/2, _imgPin.frame.origin.y+_imgPin.frame.size.height/2);
             coordPinDrag = [_mapView.projection coordinateForPoint:touchPoint];
                [self getAddressApi:coordPinDrag.latitude latLong:coordPinDrag.longitude];
       });
        return;
    }
}
-(void)getAddressApi:(double)latitude latLong:(double)longitude{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        NSLog(@"%@", responseObject);
      NSArray *aryAddress = [responseObject valueForKey:@"results"];
        if (aryAddress.count > 0)
        {
        NSDictionary *dicFullAddress = aryAddress[0];
            if (isToPlace){
        [_txtToPlace setText:[NSString stringWithFormat:@"%@",[dicFullAddress valueForKey:@"formatted_address"]]];
                _btnDrawRoute.hidden = NO;
                toPlaceLat = coordPinDrag.latitude;
                toPlaceLong = coordPinDrag.longitude;
                isFavourite = NO;
            }
            else{
                [_txtFromPlace setText:[NSString stringWithFormat:@"%@",[dicFullAddress valueForKey:@"formatted_address"]]];
                fromPlaceLat = coordPinDrag.latitude;
                fromPlaceLong = coordPinDrag.longitude;
            }
        }
        else
        {
            if (isToPlace){
            [_txtToPlace setText:[NSString stringWithFormat:@"Unnamed Road"]];
            }
            else{
                [_txtFromPlace setText:[NSString stringWithFormat:@"Unnamed Road"]];
            }
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        NSLog(@"Error : %@",error);
    };
    NSURLComponents *components = [NSURLComponents componentsWithString:@"https://maps.googleapis.com/maps/api/geocode/json"];
    NSURLQueryItem *lat = [NSURLQueryItem queryItemWithName:@"latlng" value:[NSString stringWithFormat:@"%f,%f",latitude,longitude]];
    NSURLQueryItem *key = [NSURLQueryItem queryItemWithName:@"key" value:GEOCODE_API_KEY];
    components.queryItems = @[lat,key];
    NSString *url = [NSString stringWithFormat:@"%@",components.URL];
    [ApiCall callGetWebService:url
 andDictionary:nil success:successed failure:failure];
}
- (void)getAddressFromLocation:(CLLocation *)location completionHandler:(void (^)(NSMutableDictionary *placemark))completionHandler failureHandler:(void (^)(NSError *error))failureHandler
{
    //NSMutableDictionary *d = [NSMutableDictionary new];
    CLGeocoder *geocoder = [CLGeocoder new];
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        if (failureHandler && (error || placemarks.count == 0)) {
            failureHandler(error);
        } else {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            if(completionHandler) {
                completionHandler([placemark.addressDictionary mutableCopy]);
            }
        }
    }];
}

- (void)mapView:(GMSMapView *)mapView idleAtCameraPosition:(GMSCameraPosition *)position {
    lastCameraPosition = nil; // reset pin moving, no ice skating pins ;)
}

#pragma mark - Google AutoComplete Place Controller Method -

- (void)viewController:(GMSAutocompleteViewController *)viewController
didAutocompleteWithPlace:(GMSPlace *)place {
    [self dismissViewControllerAnimated:YES completion:nil];
    NSLog(@"Place name %@", place.name);
    NSLog(@"Place name %f", place.coordinate.latitude);
    NSLog(@"Place address %@", place.formattedAddress);
    NSLog(@"Place attributions %@", place.attributions.string);
    if(!isFavourite){
        if (!isToPlace){
            _txtFromPlace.text = place.formattedAddress;
            fromPlaceLat = place.coordinate.latitude;
            fromPlaceLong = place.coordinate.longitude;
           isFavourite = YES;
        }else{
            //isFavourite = NO;
        _txtToPlace.text = place.formattedAddress;
        toPlaceLat = place.coordinate.latitude;
        toPlaceLong = place.coordinate.longitude;
        [self routeBetweenTwoLocation];
        }
    } else {
        if(index.row == 0) {
            strHomePlace = place.formattedAddress;
            objShareManager.latHome = place.coordinate.latitude;
            objShareManager.longHome = place.coordinate.longitude;
        }
        else {
            strWorkPlace = place.formattedAddress;
            objShareManager.latWork = place.coordinate.latitude;
            objShareManager.longWork = place.coordinate.longitude;
        }
        [_tblFavouritePlace reloadData];
    }
    //[self.view endEditing:YES];
}

- (void)viewController:(GMSAutocompleteViewController *)viewController didFailAutocompleteWithError:(NSError *)error {
    [self dismissViewControllerAnimated:YES completion:nil];
    [self.view endEditing:YES];
    NSLog(@"Error: %@", [error description]);
}

// User canceled the operation.
- (void)wasCancelled:(GMSAutocompleteViewController *)viewController {
    [self dismissViewControllerAnimated:YES completion:nil];
    isFavourite = YES;
}

// Turn the network activity indicator on and off again.
- (void)didRequestAutocompletePredictions:(GMSAutocompleteViewController *)viewController {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

- (void)didUpdateAutocompletePredictions:(GMSAutocompleteViewController *)viewController {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

@end
