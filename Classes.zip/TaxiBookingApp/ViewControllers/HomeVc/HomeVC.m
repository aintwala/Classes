//
//  homeVC.m
//  MyTaxiApp
//
//  Created by disha on 7/4/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "HomeVC.h"

@interface HomeVC ()

@end

@implementation HomeVC

- (void)viewDidLoad {
    objShareManager = [MPShareManager sharedManager];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL)animated{
    [self.navigationController.navigationBar setHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Action -

- (IBAction)btnRegisterAction:(id)sender {
    objShareManager.isRegister = YES;
    pushViewController(@"UserRegisterVC");
}

- (IBAction)btnSignInAction:(id)sender {
    objShareManager.isRegister = NO;
    pushViewController(@"UserRegisterVC");
}

@end
