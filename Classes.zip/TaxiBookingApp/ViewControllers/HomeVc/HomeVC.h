//
//  homeVC.h
//  MyTaxiApp
//
//  Created by disha on 7/4/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeVC : UIViewController
{
        MPShareManager *objShareManager;
}
- (IBAction)btnRegisterAction:(id)sender;
- (IBAction)btnSignInAction:(id)sender;
@end
