//
//  RatingVC.h
//  TaxiBookingApp
//
//  Created by disha on 7/12/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RatingVC : UIViewController

@end
