//
//  RatingVC.m
//  TaxiBookingApp
//
//  Created by disha on 7/12/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "RatingVC.h"

@interface RatingVC ()

@end

@implementation RatingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Review Driver";
    [self SetRatingView];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - slideNavigationController Delegate Method -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu {
    return YES;
}

#pragma mark - SetRatingView Method -

-(void)SetRatingView{
    HCSStarRatingView *starRatingView = [HCSStarRatingView new];
    starRatingView.maximumValue = 10;
    starRatingView.minimumValue = 0;
    starRatingView.value = 4;
    starRatingView.tintColor = [UIColor redColor];
    starRatingView.allowsHalfStars = YES;
    [starRatingView addTarget:self action:@selector(didChangeValue:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:starRatingView];
}

#pragma mark - ValueChanged Method -

- (IBAction)didChangeValue:(HCSStarRatingView *)sender {
    NSLog(@"Changed rating to %.1f", sender.value);
}
@end
