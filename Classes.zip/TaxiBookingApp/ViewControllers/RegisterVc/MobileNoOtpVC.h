//
//  mobileNoOtpVC.h
//  MyTaxiApp
//
//  Created by disha on 7/3/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MobileNoOtpVC : UIViewController

@property (strong, nonatomic) NSString *strMobileNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtFirstName;
@property (weak, nonatomic) IBOutlet UITextField *txtLastName;
@property (weak, nonatomic) IBOutlet UIButton *btnLoginNext;
@property (weak, nonatomic) IBOutlet UITextField *txtOtpFirst;
@property (weak, nonatomic) IBOutlet UITextField *txtOtpTwo;
@property (weak, nonatomic) IBOutlet UITextField *txtOtpThree;
@property (weak, nonatomic) IBOutlet UITextField *txtOtpFour;
@property (weak, nonatomic) IBOutlet UIView *viewUserDetail;
//
- (IBAction)btnBackAction:(id)sender;
- (IBAction)btnSignInAction:(id)sender;
- (IBAction)btnNextAction:(id)sender;

@end
