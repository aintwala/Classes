//
//  ViewController.m
//  MyTaxiApp
//
//  Created by disha on 7/3/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "UserRegisterVC.h"
@interface UserRegisterVC ()
{
    MPShareManager *objShareManager;
}
@end

@implementation UserRegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    objShareManager = [MPShareManager sharedManager];
    dictCountryCode = [NSMutableDictionary new];
    _tblCountrtyCodeList.delegate = nil;
    _tblCountrtyCodeList.dataSource = nil;
    [self setBottomBorder];
}

-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController.navigationBar setHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Text Field CALayer -

-(void)setBottomBorder{
    CALayer *bottomBorder = [CALayer layer];
    bottomBorder.frame = CGRectMake(0.0f, _txtMobileNumber.frame.size.height - 1, _txtMobileNumber.frame.size.width, 1.0f);
    bottomBorder.backgroundColor = [UIColor blackColor].CGColor;
    [_txtMobileNumber.layer addSublayer:bottomBorder];
}

#pragma mark - Text Field Delegate -

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 1){
        [self getCountryCode];
        return NO;
    }
    return YES;
}

#pragma mark - TableView Delegates -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[dictCountryCode objectForKey:@"Code"] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [_tblCountrtyCodeList dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.textLabel.text = [[dictCountryCode objectForKey:@"Code"] objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [UIColor whiteColor];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _txtCountryCode.text = [[dictCountryCode objectForKey:@"Code"] objectAtIndex:indexPath.row];
    _tblCountrtyCodeList.hidden = YES;
}

#pragma mark - Button Actions -

- (IBAction)btnBackAction:(id)sender {
  [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnNextAction:(id)sender {
    [self validation];
}

#pragma mark - Webservices -

-(void)getCountryCode{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        NSLog(@"%@", responseObject);
        dictCountryCode[@"Code"] = [responseObject allValues];
        _tblCountrtyCodeList.hidden = NO;
        _tblCountrtyCodeList.delegate = self;
        _tblCountrtyCodeList.dataSource = self;
        [_tblCountrtyCodeList reloadData];
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        NSLog(@"Error : %@",error);
    };
    [ApiCall callGetWebService:@"http://country.io/phone.json" andDictionary:nil success:successed failure:failure];
    // [ApiCall sendToService:@"http://country.io/phone.json" andDictionary:nil success:successed failure:failure];
}

-(void)signInWebservice{
    [[ApplicationData  sharedInstance]showLoader];
    NSDictionary *dic= @{@"mobile_number":_txtMobileNumber.text};
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        NSLog(@"%@",responseObject);
        if ([[NSString stringWithFormat:@"%@",[responseObject valueForKey:@"status"]] isEqualToString:@"1"])
        {
            [[ApplicationData  sharedInstance]hideLoader];
            NSDictionary *userData = [responseObject valueForKey:@"data"];
            objShareManager.strFirstName = [userData valueForKey:@"first_name"];
            objShareManager.strLastName = [userData valueForKey:@"last_name"];
            objShareManager.strMobileNumber = [userData valueForKey:@"mobile_number"];
            objShareManager.strUserId = [userData valueForKey:@"user_id"];
            objShareManager.strOtpMobileNo = [userData valueForKey:@"otp"];
            pushViewController(@"MobileNoOtpVC");
        }
        else
        {
            [[ApplicationData  sharedInstance]hideLoader];
            NSLog(@"error");
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        NSLog(@"Error : %@",error);
    };
    [ApiCall sendToService:@"http://216.55.169.45/~taxibookingapp/master/api/webservice/user_login" andDictionary:dic success:successed failure:failure];
}

-(void)MobileUpdateWebservice{
    [[ApplicationData  sharedInstance]showLoader];
    NSDictionary *dic= @{@"mobile_number":_txtMobileNumber.text,@"user_id":objShareManager.strUserId};
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        NSLog(@"%@",responseObject);
        if ([[NSString stringWithFormat:@"%@",[responseObject valueForKey:@"status"]] isEqualToString:@"1"])
        {
            [[ApplicationData  sharedInstance]hideLoader];
            objShareManager.strMobileNumber = _txtMobileNumber.text;
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        else
        {
            [[ApplicationData  sharedInstance]hideLoader];
            NSLog(@"error");
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        NSLog(@"Error : %@",error);
    };
    [ApiCall sendToService:@"http://216.55.169.45/~taxibookingapp/master/api/webservice/user_updateprofile" andDictionary:dic success:successed failure:failure];
}

#pragma - Validations -

- (void)validation{
    if ([_txtCountryCode.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Select Country Code"] animated:YES completion:nil];
    }
    else if ([_txtMobileNumber.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Mobile Number"] animated:YES completion:nil];
    }
    else {
        if (objShareManager.isUpdate) {
        [self MobileUpdateWebservice];
        }
        else{
            if(!objShareManager.isRegister){
                [self signInWebservice];
            }else{
                MobileNoOtpVC *objMobileNoOtpVC = [storyboardMain instantiateViewControllerWithIdentifier:@"MobileNoOtpVC"];
                objMobileNoOtpVC.strMobileNumber = _txtMobileNumber.text;
                [self.navigationController pushViewController:objMobileNoOtpVC animated:YES];
            }
        }
    }
}

- (BOOL)validatePhone:(NSString *)phoneNumber
{
    NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    return [phoneTest evaluateWithObject:phoneNumber];
}

@end
