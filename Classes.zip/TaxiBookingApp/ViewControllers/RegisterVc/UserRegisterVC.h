//
//  ViewController.h
//  MyTaxiApp
//
//  Created by disha on 7/3/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserRegisterVC : UIViewController <UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSMutableDictionary *dictCountryCode;
}
@property (weak, nonatomic) IBOutlet UITextField *txtMobileNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtCountryCode;
@property (weak, nonatomic) IBOutlet UIButton *btnOtpSendAction;
@property (weak, nonatomic) IBOutlet UITableView *tblCountrtyCodeList;
//
- (IBAction)btnBackAction:(id)sender;
- (IBAction)btnNextAction:(id)sender;

@end

