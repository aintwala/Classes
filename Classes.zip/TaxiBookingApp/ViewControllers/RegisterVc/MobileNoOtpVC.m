//
//  mobileNoOtpVC.m
//  MyTaxiApp
//
//  Created by disha on 7/3/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "MobileNoOtpVC.h"

@interface MobileNoOtpVC ()
{
    MPShareManager *objShareManager;
    NSString *MobNoOtp;
}
@end

@implementation MobileNoOtpVC

- (void)viewDidLoad {
    objShareManager = [MPShareManager sharedManager];
    if(!objShareManager.isRegister){
        [_btnLoginNext setTitle:@" SignIn " forState:normal];
    }
    [super viewDidLoad];
}

-(void)viewDidAppear:(BOOL)animated{
    [self.navigationController.navigationBar setHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Text Field Delegate -

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [self setTextFieldWithSpace:textField];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string stringByTrimmingCharactersInSet:
         [NSCharacterSet whitespaceCharacterSet]].length!=0) {
        textField.text=string;
        if(textField.tag<4) {
            UIView *next = [[textField superview] viewWithTag:textField.tag+1];
            [next becomeFirstResponder];
        } else if (textField.tag==4) {
            [textField resignFirstResponder];
        }
    }
    return NO;
}

-(void)setTextFieldWithSpace:(UITextField*)txtField
{
    txtField.leftViewMode = UITextFieldViewModeAlways;
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,13, txtField.frame.size.height)];
    txtField.leftView = paddingView;
}

#pragma mark - Button Actions -

- (IBAction)btnBackAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnSignInAction:(id)sender {
    [self validationSingUp];
}

- (IBAction)btnNextAction:(id)sender {
    [self validationOtp];
    if ([MobNoOtp isEqualToString:@"1234"]){
        if(objShareManager.isRegister){
            _viewUserDetail.hidden = NO;
        }
        else{
            pushViewController(@"MapViewVC");
        }
    }
    else{
//        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:[NSString stringWithFormat:@"Please enter %@ otp",Data.strOtpMobileNo]] animated:YES completion:nil];
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:[NSString stringWithFormat:@"Please enter 1234 Otp"]] animated:YES completion:nil];
    }
}

#pragma mark - Validations -

- (void)validationOtp{
    if ([_txtOtpFirst.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Your Otp"] animated:YES completion:nil];
    }
    else if ([_txtOtpTwo.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Your Otp"] animated:YES completion:nil];
    }
    else if ([_txtOtpThree.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Your Otp"] animated:YES completion:nil];
    }
    else if ([_txtOtpFour.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Your Otp"] animated:YES completion:nil];
    }
    else {
        MobNoOtp = [NSString stringWithFormat:@"%@%@%@%@",_txtOtpFirst.text,_txtOtpTwo.text,_txtOtpThree.text,_txtOtpFour.text];
        NSLog(@"%@", MobNoOtp);
    }
}

-(void)validationSingUp{
    if ([_txtFirstName.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Your First Name"] animated:YES completion:nil];
    }
    else if ([_txtLastName.text isEqualToString:@""]) {
        [self presentViewController:[ApplicationData alertWithTitle:@"" withMessage:@"Please Enter Your Last Name"] animated:YES completion:nil];
    }
    else {
        [self signUpWebservice];
    }
}

#pragma mark - WebServices -

-(void)signUpWebservice{
    [[ApplicationData  sharedInstance]showLoader];
    NSDictionary *dic= @{@"first_name":_txtFirstName.text,@"last_name":_txtLastName.text,@"mobile_number":_strMobileNumber};
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        NSLog(@"%@",responseObject);
        if ([[NSString stringWithFormat:@"%@",[responseObject valueForKey:@"status"]] isEqualToString:@"1"])
        {
            [[ApplicationData  sharedInstance]hideLoader];
            NSDictionary *userData = [responseObject valueForKey:@"data"];
            objShareManager.strFirstName = [userData valueForKey:@"first_name"];
            objShareManager.strLastName = [userData valueForKey:@"last_name"];
            objShareManager.strMobileNumber = _strMobileNumber;
            objShareManager.strUserId = [userData valueForKey:@"id"];
            pushViewController(@"MapViewVC");
        }
        else
        {
            [[ApplicationData  sharedInstance]hideLoader];
            NSLog(@"error");
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        NSLog(@"Error : %@",error);
    };
    [ApiCall sendToService:@"http://216.55.169.45/~taxibookingapp/master/api/webservice/user_signup" andDictionary:dic success:successed failure:failure];
}
@end
