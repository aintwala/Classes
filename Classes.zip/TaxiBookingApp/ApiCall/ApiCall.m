//
//  ApiCall.m
//  ShiponK_AutoLayout_WS
//
//  Created by vibha on 6/9/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "ApiCall.h"
#import <AFNetworking/AFHTTPRequestOperationManager.h>

@implementation ApiCall

+(void) sendToService:(NSString *)urlStr andDictionary:(NSDictionary *)parameter success:(void (^)(id responseObject_))success_ failure:(void (^)(NSError* _error))failure_
{
        //[[TaxiData sharedInstance] showLoader];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    AFJSONResponseSerializer *jsonReponseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    jsonReponseSerializer.acceptableContentTypes = nil;
    manager.responseSerializer = jsonReponseSerializer;

    [manager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [manager POST:urlStr parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //
        //[[TaxiData sharedInstance] hideLoader];
        if(success_)
        {
            success_(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if(failure_) {
            failure_(error);
        }
    }];
}
+(void)callGetWebService:(NSString *)urlStr andDictionary:(NSDictionary *)parameter success:(void (^)(id responseObject_))success_ failure:(void (^)(NSError* _error))failure_ {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    //manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    AFJSONResponseSerializer *jsonReponseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    jsonReponseSerializer.acceptableContentTypes = nil;
    manager.responseSerializer = jsonReponseSerializer;
    [manager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [manager GET:urlStr parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSLog(@"JSON: %@", responseObject);
         if(success_)
         {
             success_(responseObject);
         }
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"Error: %@", error);
         if(failure_) {
             failure_(error);
         }
     }];
}
@end
