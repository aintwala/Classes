//
//  ApiCall.h
//  ShiponK_AutoLayout_WS
//
//  Created by vibha on 6/9/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>
@interface ApiCall : NSObject
+(void) sendToService:(NSString *)urlStr andDictionary:(NSDictionary *)parameter success:(void (^)(id responseObject_))success_ failure:(void (^)(NSError* _error))failure_;
+(void)callGetWebService:(NSString *)urlStr andDictionary:(NSDictionary *)parameter success:(void (^)(id responseObject_))success_ failure:(void (^)(NSError* _error))failure_;
@end
