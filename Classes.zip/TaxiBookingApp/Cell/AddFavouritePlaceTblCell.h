//
//  AddFavouritePlaceTblCell.h
//  TaxiBookingApp
//
//  Created by disha on 7/12/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFavouritePlaceTblCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblAddPlace;
@property (strong, nonatomic) IBOutlet UILabel *lblPlace;

@end
