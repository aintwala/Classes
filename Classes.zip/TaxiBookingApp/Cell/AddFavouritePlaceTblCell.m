//
//  AddFavouritePlaceTblCell.m
//  TaxiBookingApp
//
//  Created by disha on 7/12/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "AddFavouritePlaceTblCell.h"

@implementation AddFavouritePlaceTblCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
